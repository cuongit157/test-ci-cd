#!/bin/bash
service nginx start

